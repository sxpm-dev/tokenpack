"use strict";(()=>{var b="tokenpack-bench-v1";function h(e){return e==="random"||e==="half"?"random":"full"}function y(e,t){return e==="full"?t:{modules:E(t.modules),styles:E(t.styles),assets:E(t.assets)}}function E(e){let t=Math.max(1,Math.ceil(e.length*.5));return[...e].sort((n,o)=>p(n.path)-p(o.path)).slice(0,t).sort((n,o)=>n.path.localeCompare(o.path))}function p(e){let t=2166136261,n=`${b}:${e}`;for(let o=0;o<n.length;o+=1)t^=n.charCodeAt(o),t=Math.imul(t,16777619);return t>>>0}var u=JSON.parse(`{
  "version": 1,
  "generatedAt": "2026-11-11T04:13:14.771Z",
  "count": 160,
  "totalBytes": 13409325,
  "modules": [
    {
      "id": 1,
      "path": "mod-0001.js",
      "bytes": 13497
    },
    {
      "id": 2,
      "path": "mod-0002.js",
      "bytes": 13490
    },
    {
      "id": 3,
      "path": "mod-0003.js",
      "bytes": 13485
    },
    {
      "id": 4,
      "path": "mod-0004.js",
      "bytes": 13495
    },
    {
      "id": 5,
      "path": "mod-0005.js",
      "bytes": 13487
    },
    {
      "id": 6,
      "path": "mod-0006.js",
      "bytes": 13502
    },
    {
      "id": 7,
      "path": "mod-0007.js",
      "bytes": 13466
    },
    {
      "id": 8,
      "path": "mod-0008.js",
      "bytes": 13485
    },
    {
      "id": 9,
      "path": "mod-0009.js",
      "bytes": 13500
    },
    {
      "id": 10,
      "path": "mod-0010.js",
      "bytes": 13510
    },
    {
      "id": 11,
      "path": "mod-0011.js",
      "bytes": 13512
    },
    {
      "id": 12,
      "path": "mod-0012.js",
      "bytes": 13498
    },
    {
      "id": 13,
      "path": "mod-0013.js",
      "bytes": 13495
    },
    {
      "id": 14,
      "path": "mod-0014.js",
      "bytes": 13495
    },
    {
      "id": 15,
      "path": "mod-0015.js",
      "bytes": 13497
    },
    {
      "id": 16,
      "path": "mod-0016.js",
      "bytes": 13495
    },
    {
      "id": 17,
      "path": "mod-0017.js",
      "bytes": 13496
    },
    {
      "id": 18,
      "path": "mod-0018.js",
      "bytes": 13490
    },
    {
      "id": 19,
      "path": "mod-0019.js",
      "bytes": 13495
    },
    {
      "id": 20,
      "path": "mod-0020.js",
      "bytes": 13502
    },
    {
      "id": 21,
      "path": "mod-0021.js",
      "bytes": 13508
    },
    {
      "id": 22,
      "path": "mod-0022.js",
      "bytes": 13496
    },
    {
      "id": 23,
      "path": "mod-0023.js",
      "bytes": 13508
    },
    {
      "id": 24,
      "path": "mod-0024.js",
      "bytes": 13487
    },
    {
      "id": 25,
      "path": "mod-0025.js",
      "bytes": 13509
    },
    {
      "id": 26,
      "path": "mod-0026.js",
      "bytes": 13499
    },
    {
      "id": 27,
      "path": "mod-0027.js",
      "bytes": 13490
    },
    {
      "id": 28,
      "path": "mod-0028.js",
      "bytes": 13496
    },
    {
      "id": 29,
      "path": "mod-0029.js",
      "bytes": 13495
    },
    {
      "id": 30,
      "path": "mod-0030.js",
      "bytes": 13493
    },
    {
      "id": 31,
      "path": "mod-0031.js",
      "bytes": 13496
    },
    {
      "id": 32,
      "path": "mod-0032.js",
      "bytes": 13501
    },
    {
      "id": 33,
      "path": "mod-0033.js",
      "bytes": 13501
    },
    {
      "id": 34,
      "path": "mod-0034.js",
      "bytes": 13495
    },
    {
      "id": 35,
      "path": "mod-0035.js",
      "bytes": 13496
    },
    {
      "id": 36,
      "path": "mod-0036.js",
      "bytes": 13504
    },
    {
      "id": 37,
      "path": "mod-0037.js",
      "bytes": 13490
    },
    {
      "id": 38,
      "path": "mod-0038.js",
      "bytes": 13510
    },
    {
      "id": 39,
      "path": "mod-0039.js",
      "bytes": 13496
    },
    {
      "id": 40,
      "path": "mod-0040.js",
      "bytes": 13498
    },
    {
      "id": 41,
      "path": "mod-0041.js",
      "bytes": 13499
    },
    {
      "id": 42,
      "path": "mod-0042.js",
      "bytes": 13502
    },
    {
      "id": 43,
      "path": "mod-0043.js",
      "bytes": 13495
    },
    {
      "id": 44,
      "path": "mod-0044.js",
      "bytes": 13486
    },
    {
      "id": 45,
      "path": "mod-0045.js",
      "bytes": 13500
    },
    {
      "id": 46,
      "path": "mod-0046.js",
      "bytes": 13490
    },
    {
      "id": 47,
      "path": "mod-0047.js",
      "bytes": 13509
    },
    {
      "id": 48,
      "path": "mod-0048.js",
      "bytes": 13503
    },
    {
      "id": 49,
      "path": "mod-0049.js",
      "bytes": 13499
    },
    {
      "id": 50,
      "path": "mod-0050.js",
      "bytes": 13481
    },
    {
      "id": 51,
      "path": "mod-0051.js",
      "bytes": 13490
    },
    {
      "id": 52,
      "path": "mod-0052.js",
      "bytes": 13506
    },
    {
      "id": 53,
      "path": "mod-0053.js",
      "bytes": 13497
    },
    {
      "id": 54,
      "path": "mod-0054.js",
      "bytes": 13486
    },
    {
      "id": 55,
      "path": "mod-0055.js",
      "bytes": 13477
    },
    {
      "id": 56,
      "path": "mod-0056.js",
      "bytes": 13493
    },
    {
      "id": 57,
      "path": "mod-0057.js",
      "bytes": 13491
    },
    {
      "id": 58,
      "path": "mod-0058.js",
      "bytes": 13512
    },
    {
      "id": 59,
      "path": "mod-0059.js",
      "bytes": 13482
    },
    {
      "id": 60,
      "path": "mod-0060.js",
      "bytes": 13497
    },
    {
      "id": 61,
      "path": "mod-0061.js",
      "bytes": 13505
    },
    {
      "id": 62,
      "path": "mod-0062.js",
      "bytes": 13497
    },
    {
      "id": 63,
      "path": "mod-0063.js",
      "bytes": 13482
    },
    {
      "id": 64,
      "path": "mod-0064.js",
      "bytes": 13498
    },
    {
      "id": 65,
      "path": "mod-0065.js",
      "bytes": 13490
    },
    {
      "id": 66,
      "path": "mod-0066.js",
      "bytes": 13504
    },
    {
      "id": 67,
      "path": "mod-0067.js",
      "bytes": 13505
    },
    {
      "id": 68,
      "path": "mod-0068.js",
      "bytes": 13495
    },
    {
      "id": 69,
      "path": "mod-0069.js",
      "bytes": 13497
    },
    {
      "id": 70,
      "path": "mod-0070.js",
      "bytes": 13492
    },
    {
      "id": 71,
      "path": "mod-0071.js",
      "bytes": 13496
    },
    {
      "id": 72,
      "path": "mod-0072.js",
      "bytes": 13492
    },
    {
      "id": 73,
      "path": "mod-0073.js",
      "bytes": 13501
    },
    {
      "id": 74,
      "path": "mod-0074.js",
      "bytes": 13496
    },
    {
      "id": 75,
      "path": "mod-0075.js",
      "bytes": 13505
    },
    {
      "id": 76,
      "path": "mod-0076.js",
      "bytes": 13488
    },
    {
      "id": 77,
      "path": "mod-0077.js",
      "bytes": 13499
    },
    {
      "id": 78,
      "path": "mod-0078.js",
      "bytes": 13489
    },
    {
      "id": 79,
      "path": "mod-0079.js",
      "bytes": 13492
    },
    {
      "id": 80,
      "path": "mod-0080.js",
      "bytes": 13490
    },
    {
      "id": 81,
      "path": "mod-0081.js",
      "bytes": 13503
    },
    {
      "id": 82,
      "path": "mod-0082.js",
      "bytes": 13504
    },
    {
      "id": 83,
      "path": "mod-0083.js",
      "bytes": 13509
    },
    {
      "id": 84,
      "path": "mod-0084.js",
      "bytes": 13499
    },
    {
      "id": 85,
      "path": "mod-0085.js",
      "bytes": 13498
    },
    {
      "id": 86,
      "path": "mod-0086.js",
      "bytes": 13511
    },
    {
      "id": 87,
      "path": "mod-0087.js",
      "bytes": 13502
    },
    {
      "id": 88,
      "path": "mod-0088.js",
      "bytes": 13480
    },
    {
      "id": 89,
      "path": "mod-0089.js",
      "bytes": 13492
    },
    {
      "id": 90,
      "path": "mod-0090.js",
      "bytes": 13499
    },
    {
      "id": 91,
      "path": "mod-0091.js",
      "bytes": 13484
    },
    {
      "id": 92,
      "path": "mod-0092.js",
      "bytes": 13500
    },
    {
      "id": 93,
      "path": "mod-0093.js",
      "bytes": 13490
    },
    {
      "id": 94,
      "path": "mod-0094.js",
      "bytes": 13488
    },
    {
      "id": 95,
      "path": "mod-0095.js",
      "bytes": 13481
    },
    {
      "id": 96,
      "path": "mod-0096.js",
      "bytes": 13500
    },
    {
      "id": 97,
      "path": "mod-0097.js",
      "bytes": 13489
    },
    {
      "id": 98,
      "path": "mod-0098.js",
      "bytes": 13488
    },
    {
      "id": 99,
      "path": "mod-0099.js",
      "bytes": 13490
    },
    {
      "id": 100,
      "path": "mod-0100.js",
      "bytes": 13493
    },
    {
      "id": 101,
      "path": "mod-0101.js",
      "bytes": 13497
    },
    {
      "id": 102,
      "path": "mod-0102.js",
      "bytes": 13498
    },
    {
      "id": 103,
      "path": "mod-0103.js",
      "bytes": 13499
    },
    {
      "id": 104,
      "path": "mod-0104.js",
      "bytes": 13487
    },
    {
      "id": 105,
      "path": "mod-0105.js",
      "bytes": 13497
    },
    {
      "id": 106,
      "path": "mod-0106.js",
      "bytes": 13491
    },
    {
      "id": 107,
      "path": "mod-0107.js",
      "bytes": 13504
    },
    {
      "id": 108,
      "path": "mod-0108.js",
      "bytes": 13483
    },
    {
      "id": 109,
      "path": "mod-0109.js",
      "bytes": 13502
    },
    {
      "id": 110,
      "path": "mod-0110.js",
      "bytes": 13487
    },
    {
      "id": 111,
      "path": "mod-0111.js",
      "bytes": 13505
    },
    {
      "id": 112,
      "path": "mod-0112.js",
      "bytes": 13499
    },
    {
      "id": 113,
      "path": "mod-0113.js",
      "bytes": 13491
    },
    {
      "id": 114,
      "path": "mod-0114.js",
      "bytes": 13504
    },
    {
      "id": 115,
      "path": "mod-0115.js",
      "bytes": 13506
    },
    {
      "id": 116,
      "path": "mod-0116.js",
      "bytes": 13503
    },
    {
      "id": 117,
      "path": "mod-0117.js",
      "bytes": 13489
    },
    {
      "id": 118,
      "path": "mod-0118.js",
      "bytes": 13490
    },
    {
      "id": 119,
      "path": "mod-0119.js",
      "bytes": 13507
    },
    {
      "id": 120,
      "path": "mod-0120.js",
      "bytes": 13493
    },
    {
      "id": 121,
      "path": "mod-0121.js",
      "bytes": 13498
    },
    {
      "id": 122,
      "path": "mod-0122.js",
      "bytes": 13513
    },
    {
      "id": 123,
      "path": "mod-0123.js",
      "bytes": 13499
    },
    {
      "id": 124,
      "path": "mod-0124.js",
      "bytes": 13506
    },
    {
      "id": 125,
      "path": "mod-0125.js",
      "bytes": 13498
    },
    {
      "id": 126,
      "path": "mod-0126.js",
      "bytes": 13509
    },
    {
      "id": 127,
      "path": "mod-0127.js",
      "bytes": 13483
    },
    {
      "id": 128,
      "path": "mod-0128.js",
      "bytes": 13508
    },
    {
      "id": 129,
      "path": "mod-0129.js",
      "bytes": 13515
    },
    {
      "id": 130,
      "path": "mod-0130.js",
      "bytes": 13505
    },
    {
      "id": 131,
      "path": "mod-0131.js",
      "bytes": 13511
    },
    {
      "id": 132,
      "path": "mod-0132.js",
      "bytes": 13513
    },
    {
      "id": 133,
      "path": "mod-0133.js",
      "bytes": 13497
    },
    {
      "id": 134,
      "path": "mod-0134.js",
      "bytes": 13491
    },
    {
      "id": 135,
      "path": "mod-0135.js",
      "bytes": 13491
    },
    {
      "id": 136,
      "path": "mod-0136.js",
      "bytes": 13504
    },
    {
      "id": 137,
      "path": "mod-0137.js",
      "bytes": 13494
    },
    {
      "id": 138,
      "path": "mod-0138.js",
      "bytes": 13511
    },
    {
      "id": 139,
      "path": "mod-0139.js",
      "bytes": 13503
    },
    {
      "id": 140,
      "path": "mod-0140.js",
      "bytes": 13506
    },
    {
      "id": 141,
      "path": "mod-0141.js",
      "bytes": 13500
    },
    {
      "id": 142,
      "path": "mod-0142.js",
      "bytes": 13499
    },
    {
      "id": 143,
      "path": "mod-0143.js",
      "bytes": 13498
    },
    {
      "id": 144,
      "path": "mod-0144.js",
      "bytes": 13493
    },
    {
      "id": 145,
      "path": "mod-0145.js",
      "bytes": 13504
    },
    {
      "id": 146,
      "path": "mod-0146.js",
      "bytes": 13497
    },
    {
      "id": 147,
      "path": "mod-0147.js",
      "bytes": 13490
    },
    {
      "id": 148,
      "path": "mod-0148.js",
      "bytes": 13485
    },
    {
      "id": 149,
      "path": "mod-0149.js",
      "bytes": 13500
    },
    {
      "id": 150,
      "path": "mod-0150.js",
      "bytes": 13486
    },
    {
      "id": 151,
      "path": "mod-0151.js",
      "bytes": 13498
    },
    {
      "id": 152,
      "path": "mod-0152.js",
      "bytes": 13488
    },
    {
      "id": 153,
      "path": "mod-0153.js",
      "bytes": 13515
    },
    {
      "id": 154,
      "path": "mod-0154.js",
      "bytes": 13495
    },
    {
      "id": 155,
      "path": "mod-0155.js",
      "bytes": 13493
    },
    {
      "id": 156,
      "path": "mod-0156.js",
      "bytes": 13499
    },
    {
      "id": 157,
      "path": "mod-0157.js",
      "bytes": 13492
    },
    {
      "id": 158,
      "path": "mod-0158.js",
      "bytes": 13501
    },
    {
      "id": 159,
      "path": "mod-0159.js",
      "bytes": 13498
    },
    {
      "id": 160,
      "path": "mod-0160.js",
      "bytes": 13496
    }
  ],
  "styles": [
    {
      "kind": "css",
      "path": "style-0001.css",
      "bytes": 10284,
      "contentType": "text/css"
    },
    {
      "kind": "css",
      "path": "style-0002.css",
      "bytes": 10257,
      "contentType": "text/css"
    },
    {
      "kind": "css",
      "path": "style-0003.css",
      "bytes": 10247,
      "contentType": "text/css"
    },
    {
      "kind": "css",
      "path": "style-0004.css",
      "bytes": 10258,
      "contentType": "text/css"
    },
    {
      "kind": "css",
      "path": "style-0005.css",
      "bytes": 10264,
      "contentType": "text/css"
    },
    {
      "kind": "css",
      "path": "style-0006.css",
      "bytes": 10271,
      "contentType": "text/css"
    },
    {
      "kind": "css",
      "path": "style-0007.css",
      "bytes": 10259,
      "contentType": "text/css"
    },
    {
      "kind": "css",
      "path": "style-0008.css",
      "bytes": 10270,
      "contentType": "text/css"
    },
    {
      "kind": "css",
      "path": "style-0009.css",
      "bytes": 10283,
      "contentType": "text/css"
    },
    {
      "kind": "css",
      "path": "style-0010.css",
      "bytes": 10256,
      "contentType": "text/css"
    },
    {
      "kind": "css",
      "path": "style-0011.css",
      "bytes": 10273,
      "contentType": "text/css"
    },
    {
      "kind": "css",
      "path": "style-0012.css",
      "bytes": 10279,
      "contentType": "text/css"
    },
    {
      "kind": "css",
      "path": "style-0013.css",
      "bytes": 10264,
      "contentType": "text/css"
    },
    {
      "kind": "css",
      "path": "style-0014.css",
      "bytes": 10272,
      "contentType": "text/css"
    },
    {
      "kind": "css",
      "path": "style-0015.css",
      "bytes": 10266,
      "contentType": "text/css"
    },
    {
      "kind": "css",
      "path": "style-0016.css",
      "bytes": 10278,
      "contentType": "text/css"
    },
    {
      "kind": "css",
      "path": "style-0017.css",
      "bytes": 10277,
      "contentType": "text/css"
    },
    {
      "kind": "css",
      "path": "style-0018.css",
      "bytes": 10282,
      "contentType": "text/css"
    },
    {
      "kind": "css",
      "path": "style-0019.css",
      "bytes": 10273,
      "contentType": "text/css"
    },
    {
      "kind": "css",
      "path": "style-0020.css",
      "bytes": 10266,
      "contentType": "text/css"
    },
    {
      "kind": "css",
      "path": "style-0021.css",
      "bytes": 10274,
      "contentType": "text/css"
    },
    {
      "kind": "css",
      "path": "style-0022.css",
      "bytes": 10269,
      "contentType": "text/css"
    },
    {
      "kind": "css",
      "path": "style-0023.css",
      "bytes": 10276,
      "contentType": "text/css"
    },
    {
      "kind": "css",
      "path": "style-0024.css",
      "bytes": 10278,
      "contentType": "text/css"
    },
    {
      "kind": "css",
      "path": "style-0025.css",
      "bytes": 10272,
      "contentType": "text/css"
    },
    {
      "kind": "css",
      "path": "style-0026.css",
      "bytes": 10281,
      "contentType": "text/css"
    },
    {
      "kind": "css",
      "path": "style-0027.css",
      "bytes": 10261,
      "contentType": "text/css"
    },
    {
      "kind": "css",
      "path": "style-0028.css",
      "bytes": 10268,
      "contentType": "text/css"
    },
    {
      "kind": "css",
      "path": "style-0029.css",
      "bytes": 10274,
      "contentType": "text/css"
    },
    {
      "kind": "css",
      "path": "style-0030.css",
      "bytes": 10277,
      "contentType": "text/css"
    },
    {
      "kind": "css",
      "path": "style-0031.css",
      "bytes": 10265,
      "contentType": "text/css"
    },
    {
      "kind": "css",
      "path": "style-0032.css",
      "bytes": 10263,
      "contentType": "text/css"
    },
    {
      "kind": "css",
      "path": "style-0033.css",
      "bytes": 10271,
      "contentType": "text/css"
    },
    {
      "kind": "css",
      "path": "style-0034.css",
      "bytes": 10267,
      "contentType": "text/css"
    },
    {
      "kind": "css",
      "path": "style-0035.css",
      "bytes": 10274,
      "contentType": "text/css"
    },
    {
      "kind": "css",
      "path": "style-0036.css",
      "bytes": 10287,
      "contentType": "text/css"
    },
    {
      "kind": "css",
      "path": "style-0037.css",
      "bytes": 10270,
      "contentType": "text/css"
    },
    {
      "kind": "css",
      "path": "style-0038.css",
      "bytes": 10270,
      "contentType": "text/css"
    },
    {
      "kind": "css",
      "path": "style-0039.css",
      "bytes": 10276,
      "contentType": "text/css"
    },
    {
      "kind": "css",
      "path": "style-0040.css",
      "bytes": 10270,
      "contentType": "text/css"
    }
  ],
  "assets": [
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-small-0001.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-small-0002.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-small-0003.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-small-0004.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-small-0005.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-small-0006.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-small-0007.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-small-0008.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-small-0009.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-small-0010.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-small-0011.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-small-0012.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-small-0013.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-small-0014.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-small-0015.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-small-0016.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-small-0017.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-small-0018.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-small-0019.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-small-0020.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-small-0021.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-small-0022.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-small-0023.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-small-0024.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-small-0025.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-small-0026.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-small-0027.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-small-0028.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-small-0029.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-small-0030.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-small-0031.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-small-0032.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-small-0033.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-small-0034.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-small-0035.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-small-0036.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-small-0037.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-small-0038.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-small-0039.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-small-0040.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-small-0041.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-small-0042.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-small-0043.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-small-0044.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-small-0045.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-small-0046.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-small-0047.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-small-0048.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-small-0049.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-small-0050.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-small-0051.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-small-0052.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-small-0053.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-small-0054.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-small-0055.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-small-0056.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-small-0057.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-small-0058.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-small-0059.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-small-0060.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-small-0061.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-small-0062.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-small-0063.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-small-0064.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-small-0065.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-small-0066.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-small-0067.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-small-0068.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-small-0069.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-small-0070.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-small-0071.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-small-0072.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-small-0073.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-small-0074.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-small-0075.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-small-0076.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-small-0077.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-small-0078.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-small-0079.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-small-0080.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "medium",
      "path": "img-medium-0081.png",
      "bytes": 187873,
      "width": 250,
      "height": 250,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "medium",
      "path": "img-medium-0082.png",
      "bytes": 187873,
      "width": 250,
      "height": 250,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "medium",
      "path": "img-medium-0083.png",
      "bytes": 187873,
      "width": 250,
      "height": 250,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "medium",
      "path": "img-medium-0084.png",
      "bytes": 187873,
      "width": 250,
      "height": 250,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "medium",
      "path": "img-medium-0085.png",
      "bytes": 187873,
      "width": 250,
      "height": 250,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "medium",
      "path": "img-medium-0086.png",
      "bytes": 187873,
      "width": 250,
      "height": 250,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "medium",
      "path": "img-medium-0087.png",
      "bytes": 187873,
      "width": 250,
      "height": 250,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "medium",
      "path": "img-medium-0088.png",
      "bytes": 187873,
      "width": 250,
      "height": 250,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "medium",
      "path": "img-medium-0089.png",
      "bytes": 187873,
      "width": 250,
      "height": 250,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "medium",
      "path": "img-medium-0090.png",
      "bytes": 187873,
      "width": 250,
      "height": 250,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "medium",
      "path": "img-medium-0091.png",
      "bytes": 187873,
      "width": 250,
      "height": 250,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "medium",
      "path": "img-medium-0092.png",
      "bytes": 187873,
      "width": 250,
      "height": 250,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "medium",
      "path": "img-medium-0093.png",
      "bytes": 187873,
      "width": 250,
      "height": 250,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "medium",
      "path": "img-medium-0094.png",
      "bytes": 187873,
      "width": 250,
      "height": 250,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "medium",
      "path": "img-medium-0095.png",
      "bytes": 187873,
      "width": 250,
      "height": 250,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "medium",
      "path": "img-medium-0096.png",
      "bytes": 187873,
      "width": 250,
      "height": 250,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "medium",
      "path": "img-medium-0097.png",
      "bytes": 187873,
      "width": 250,
      "height": 250,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "medium",
      "path": "img-medium-0098.png",
      "bytes": 187873,
      "width": 250,
      "height": 250,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "medium",
      "path": "img-medium-0099.png",
      "bytes": 187873,
      "width": 250,
      "height": 250,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "medium",
      "path": "img-medium-0100.png",
      "bytes": 187873,
      "width": 250,
      "height": 250,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "large",
      "path": "img-large-0101.png",
      "bytes": 1471213,
      "width": 700,
      "height": 700,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "large",
      "path": "img-large-0102.png",
      "bytes": 1471213,
      "width": 700,
      "height": 700,
      "contentType": "image/png"
    }
  ],
  "lazyModules": [
    {
      "id": 1,
      "path": "mod-lazy-0001.js",
      "bytes": 13410,
      "contentType": "application/javascript"
    },
    {
      "id": 2,
      "path": "mod-lazy-0002.js",
      "bytes": 13435,
      "contentType": "application/javascript"
    },
    {
      "id": 3,
      "path": "mod-lazy-0003.js",
      "bytes": 13421,
      "contentType": "application/javascript"
    },
    {
      "id": 4,
      "path": "mod-lazy-0004.js",
      "bytes": 13412,
      "contentType": "application/javascript"
    },
    {
      "id": 5,
      "path": "mod-lazy-0005.js",
      "bytes": 13411,
      "contentType": "application/javascript"
    },
    {
      "id": 6,
      "path": "mod-lazy-0006.js",
      "bytes": 13424,
      "contentType": "application/javascript"
    },
    {
      "id": 7,
      "path": "mod-lazy-0007.js",
      "bytes": 13411,
      "contentType": "application/javascript"
    },
    {
      "id": 8,
      "path": "mod-lazy-0008.js",
      "bytes": 13417,
      "contentType": "application/javascript"
    },
    {
      "id": 9,
      "path": "mod-lazy-0009.js",
      "bytes": 13421,
      "contentType": "application/javascript"
    },
    {
      "id": 10,
      "path": "mod-lazy-0010.js",
      "bytes": 13423,
      "contentType": "application/javascript"
    },
    {
      "id": 11,
      "path": "mod-lazy-0011.js",
      "bytes": 13431,
      "contentType": "application/javascript"
    },
    {
      "id": 12,
      "path": "mod-lazy-0012.js",
      "bytes": 13434,
      "contentType": "application/javascript"
    },
    {
      "id": 13,
      "path": "mod-lazy-0013.js",
      "bytes": 13428,
      "contentType": "application/javascript"
    },
    {
      "id": 14,
      "path": "mod-lazy-0014.js",
      "bytes": 13411,
      "contentType": "application/javascript"
    },
    {
      "id": 15,
      "path": "mod-lazy-0015.js",
      "bytes": 13435,
      "contentType": "application/javascript"
    },
    {
      "id": 16,
      "path": "mod-lazy-0016.js",
      "bytes": 13419,
      "contentType": "application/javascript"
    },
    {
      "id": 17,
      "path": "mod-lazy-0017.js",
      "bytes": 13418,
      "contentType": "application/javascript"
    },
    {
      "id": 18,
      "path": "mod-lazy-0018.js",
      "bytes": 13434,
      "contentType": "application/javascript"
    },
    {
      "id": 19,
      "path": "mod-lazy-0019.js",
      "bytes": 13422,
      "contentType": "application/javascript"
    },
    {
      "id": 20,
      "path": "mod-lazy-0020.js",
      "bytes": 13423,
      "contentType": "application/javascript"
    },
    {
      "id": 21,
      "path": "mod-lazy-0021.js",
      "bytes": 13420,
      "contentType": "application/javascript"
    },
    {
      "id": 22,
      "path": "mod-lazy-0022.js",
      "bytes": 13440,
      "contentType": "application/javascript"
    },
    {
      "id": 23,
      "path": "mod-lazy-0023.js",
      "bytes": 13428,
      "contentType": "application/javascript"
    },
    {
      "id": 24,
      "path": "mod-lazy-0024.js",
      "bytes": 13425,
      "contentType": "application/javascript"
    },
    {
      "id": 25,
      "path": "mod-lazy-0025.js",
      "bytes": 13414,
      "contentType": "application/javascript"
    },
    {
      "id": 26,
      "path": "mod-lazy-0026.js",
      "bytes": 13413,
      "contentType": "application/javascript"
    },
    {
      "id": 27,
      "path": "mod-lazy-0027.js",
      "bytes": 13407,
      "contentType": "application/javascript"
    },
    {
      "id": 28,
      "path": "mod-lazy-0028.js",
      "bytes": 13417,
      "contentType": "application/javascript"
    },
    {
      "id": 29,
      "path": "mod-lazy-0029.js",
      "bytes": 13418,
      "contentType": "application/javascript"
    },
    {
      "id": 30,
      "path": "mod-lazy-0030.js",
      "bytes": 13410,
      "contentType": "application/javascript"
    },
    {
      "id": 31,
      "path": "mod-lazy-0031.js",
      "bytes": 13431,
      "contentType": "application/javascript"
    },
    {
      "id": 32,
      "path": "mod-lazy-0032.js",
      "bytes": 13420,
      "contentType": "application/javascript"
    },
    {
      "id": 33,
      "path": "mod-lazy-three.js",
      "bytes": 480456,
      "contentType": "application/javascript"
    }
  ],
  "lazyStyles": [
    {
      "id": 1,
      "path": "style-lazy-0001.css",
      "bytes": 10302,
      "contentType": "text/css"
    },
    {
      "id": 2,
      "path": "style-lazy-0002.css",
      "bytes": 10314,
      "contentType": "text/css"
    },
    {
      "id": 3,
      "path": "style-lazy-0003.css",
      "bytes": 10309,
      "contentType": "text/css"
    },
    {
      "id": 4,
      "path": "style-lazy-0004.css",
      "bytes": 10312,
      "contentType": "text/css"
    },
    {
      "id": 5,
      "path": "style-lazy-0005.css",
      "bytes": 10300,
      "contentType": "text/css"
    },
    {
      "id": 6,
      "path": "style-lazy-0006.css",
      "bytes": 10308,
      "contentType": "text/css"
    },
    {
      "id": 7,
      "path": "style-lazy-0007.css",
      "bytes": 10306,
      "contentType": "text/css"
    },
    {
      "id": 8,
      "path": "style-lazy-0008.css",
      "bytes": 10311,
      "contentType": "text/css"
    },
    {
      "id": 9,
      "path": "style-lazy-0009.css",
      "bytes": 10313,
      "contentType": "text/css"
    },
    {
      "id": 10,
      "path": "style-lazy-0010.css",
      "bytes": 10310,
      "contentType": "text/css"
    },
    {
      "id": 11,
      "path": "style-lazy-0011.css",
      "bytes": 10316,
      "contentType": "text/css"
    },
    {
      "id": 12,
      "path": "style-lazy-0012.css",
      "bytes": 10307,
      "contentType": "text/css"
    }
  ],
  "lazyAssets": [
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-lazy-small-0001.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-lazy-small-0002.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-lazy-small-0003.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-lazy-small-0004.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-lazy-small-0005.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-lazy-small-0006.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-lazy-small-0007.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-lazy-small-0008.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-lazy-small-0009.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-lazy-small-0010.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-lazy-small-0011.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-lazy-small-0012.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-lazy-small-0013.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-lazy-small-0014.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-lazy-small-0015.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-lazy-small-0016.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-lazy-small-0017.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-lazy-small-0018.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-lazy-small-0019.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-lazy-small-0020.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-lazy-small-0021.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-lazy-small-0022.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-lazy-small-0023.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-lazy-small-0024.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-lazy-small-0025.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-lazy-small-0026.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-lazy-small-0027.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "small",
      "path": "img-lazy-small-0028.png",
      "bytes": 14838,
      "width": 70,
      "height": 70,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "medium",
      "path": "img-lazy-medium-0029.png",
      "bytes": 187873,
      "width": 250,
      "height": 250,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "medium",
      "path": "img-lazy-medium-0030.png",
      "bytes": 187873,
      "width": 250,
      "height": 250,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "medium",
      "path": "img-lazy-medium-0031.png",
      "bytes": 187873,
      "width": 250,
      "height": 250,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "medium",
      "path": "img-lazy-medium-0032.png",
      "bytes": 187873,
      "width": 250,
      "height": 250,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "medium",
      "path": "img-lazy-medium-0033.png",
      "bytes": 187873,
      "width": 250,
      "height": 250,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "medium",
      "path": "img-lazy-medium-0034.png",
      "bytes": 187873,
      "width": 250,
      "height": 250,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "medium",
      "path": "img-lazy-medium-0035.png",
      "bytes": 187873,
      "width": 250,
      "height": 250,
      "contentType": "image/png"
    },
    {
      "kind": "image",
      "bucket": "medium",
      "path": "img-lazy-medium-0036.png",
      "bytes": 187873,
      "width": 250,
      "height": 250,
      "contentType": "image/png"
    }
  ]
}`),f=new URLSearchParams(location.search),m=f.get("origin")??"local",S=h(f.get("scope")),C=f.get("cdnBase"),A=C??("".startsWith("http"),""),i=m==="cdn"?A.replace(/\/$/,""):"/bench-app/medium/assets";window.__BENCH_VARIANT={loader:"native-dynamic",origin:m,base:i};H();async function H(){let e=performance.now(),t={manifestMs:0},n=x(u);g(`eager: ${M(n)} \xB7 native-dynamic \xB7 ${O(S)}`);let o=I(),s=performance.now(),r=[];for(let a of n.modules)r.push(w(`${i}/${a.path}`));for(let a of n.styles)r.push(N(`${i}/${a.path}`));for(let a of n.assets)r.push(L(`${i}/${a.path}`,o));await Promise.all(r),t.loadMs=performance.now()-s;let d=performance.now();R(n.modules),t.renderMs=performance.now()-d;let l=performance.now()-e;window.__BENCH_BOOT_DONE=l,window.__BENCH_PHASES=t,document.title=`native-dynamic/${m} \xB7 boot ${Math.round(l)}ms`,g(`boot ${Math.round(l)} ms \xB7 load ${Math.round(t.loadMs)} ms (${M(n)}) \xB7 render ${Math.round(t.renderMs)} ms (${n.modules.length} modules)`),$(),window.dispatchEvent(new CustomEvent("bench:boot:done",{detail:{loader:"native-dynamic",origin:m,totalMs:l,phases:t}}))}function $(){let e=document.getElementById("open-dialog");e&&(e.disabled=!1,e.addEventListener("click",()=>{P()},{once:!0}))}async function P(){let e=performance.now(),t={},n=T();B("loading\u2026");let o=performance.now(),s=[],r=[];for(let c of u.lazyModules??[])r.push(w(`${i}/${c.path}`));for(let c of u.lazyStyles??[])r.push(N(`${i}/${c.path}`));for(let c of u.lazyAssets??[]){let _=v(`${i}/${c.path}`);s.push(_),r.push(_)}await Promise.all(r);let d=await Promise.all(s);t.loadMs=performance.now()-o;let l=performance.now();if(z(n),window.__BENCH_LAZY?.initScene){let c=n.querySelector(".scene");c&&window.__BENCH_LAZY.initScene(c,d)}t.renderMs=performance.now()-l;let a=performance.now()-e;window.__BENCH_LAZY_DONE=a,window.__BENCH_LAZY_PHASES=t,B(`done \xB7 ${Math.round(a)}ms (load ${Math.round(t.loadMs)} \xB7 render ${Math.round(t.renderMs)})`),window.dispatchEvent(new CustomEvent("bench:lazy:done",{detail:{loader:"native-dynamic",origin:m,totalMs:a,phases:t}}))}function w(e){return new Promise((t,n)=>{let o=document.createElement("script");o.src=e,o.async=!0,o.onload=()=>t(),o.onerror=()=>n(new Error(`script failed: ${e}`)),document.head.appendChild(o)})}function N(e){return new Promise((t,n)=>{let o=document.createElement("link");o.rel="stylesheet",o.href=e,o.onload=()=>t(),o.onerror=()=>n(new Error(`stylesheet failed: ${e}`)),document.head.appendChild(o)})}function L(e,t){return new Promise((n,o)=>{let s=new Image;s.src=e,s.decoding="async",s.loading="eager",t.appendChild(s),s.decode().then(()=>n()).catch(o)})}async function v(e){let t=await fetch(e,{cache:"no-store"});if(!t.ok)throw new Error(`image fetch failed: ${t.status} ${e}`);let n=await t.blob();return createImageBitmap(n)}function I(){let e=document.getElementById("images");return e||(e=document.createElement("div"),e.id="images",document.body.appendChild(e)),e}function T(){let e=document.getElementById("lazy-dialog");if(e)return e;let t=document.createElement("div");t.id="lazy-dialog";let n=document.createElement("div");n.className="bar";let o=document.createElement("strong");o.textContent="Lazy dialog",n.append(o,document.createTextNode(" \xB7 "));let s=document.createElement("span");s.id="lazy-status",s.textContent="opening",n.appendChild(s);let r=document.createElement("div");r.className="scene";let d=document.createElement("div");return d.className="tags",t.append(n,r,d),document.body.appendChild(t),t}function g(e){let t=document.getElementById("status");t&&(t.textContent=e)}function B(e){let t=document.getElementById("lazy-status");t&&(t.textContent=e)}function x(e){let t=e.modules,n=e.styles??[],o=e.assets??[];return y(S,{modules:t,styles:n,assets:o})}function M(e){return`${e.modules.length} JS + ${e.styles.length} CSS + ${e.assets.length} PNG`}function O(e){return e==="random"?"50% deterministic random request set":"full app request set"}function R(e){let t=document.getElementById("root");if(!t)throw new Error("#root missing");let n=window.__BENCH_MODULES??{},o=e.map(s=>s.id).filter(s=>s!==void 0);for(let s of o)n[s]?.render(t)}function z(e){let t=e.querySelector(".tags");if(!t)return;let n=window.__BENCH_LAZY_MODULES??{},o=Object.keys(n).map(Number).sort((s,r)=>s-r);for(let s of o)n[s]?.render(t)}})();
//# sourceMappingURL=entry-dynamic.js.map
